import ReadNote from "./ReadNote"


export default function Home()
{

    return(
        <div className="home-cont">
            <ReadNote/> 
        </div>
       
    )
}










